<div class="sidebar col-lg-2 offcanvas-lg offcanvas-start p-3 d-flex flex-column text-white" tabindex="-1" id="adminSidebar" aria-labelledby="adminSidebarLabel">
    <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom border-secondary border-opacity-25">
        <h5 class="text-white mb-0" id="adminSidebarLabel">Admin Panel</h5>
        <div class="d-flex align-items-center gap-2">
            <a href="<?php echo e(Route::has('home') ? route('home') : url('/')); ?>" target="_blank"
                class="btn btn-sm btn-outline-light border-secondary text-white py-1 px-2"
                title="View Frontend Website">
                <i class="bi bi-globe"></i>
            </a>
            <button type="button" class="btn-close btn-close-white d-lg-none" data-bs-dismiss="offcanvas" data-bs-target="#adminSidebar" aria-label="Close"></button>
        </div>
    </div>

    
    <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
        <i class="bi bi-speedometer2 me-2"></i> Dashboard
    </a>

    
    <?php
        $pendingOrdersCount = \App\Models\ServiceOrder::where('order_status', 'pending')->count();
    ?>
    <a href="<?php echo e(route('admin.orders.index')); ?>"
        class="d-flex justify-content-between align-items-center <?php echo e(request()->routeIs('admin.orders.*') ? 'active' : ''); ?>">
        <span>
            <i class="bi bi-receipt-cutoff me-2 text-info"></i>
            কাজের অর্ডার (Orders)
        </span>
        <?php if($pendingOrdersCount > 0): ?>
            <span class="badge bg-warning text-dark rounded-pill px-2 py-1" style="font-size: 0.75rem; font-weight: 700;">
                <?php echo e($pendingOrdersCount); ?>

            </span>
        <?php endif; ?>
    </a>

    
    <a href="<?php echo e(route('admin.customers.index')); ?>"
        class="<?php echo e(request()->routeIs('admin.customers.*') ? 'active' : ''); ?>">
        <i class="bi bi-person-lines-fill me-2 text-success"></i> গ্রাহক অনুসন্ধান (Customers)
    </a>

    
    <a href="<?php echo e(route('admin.useful-links.index')); ?>"
        class="<?php echo e(request()->routeIs('admin.useful-links.*') ? 'active' : ''); ?>">
        <i class="bi bi-link-45deg me-2 text-warning"></i> প্রয়োজনীয় লিংক (Links)
    </a>

    
    <a href="<?php echo e(route('admin.contacts.index')); ?>"
        class="d-flex justify-content-between align-items-center <?php echo e(request()->routeIs('admin.contacts.*') ? 'active' : ''); ?>">
        <span>
            <i class="bi bi-envelope<?php echo e(!empty($unreadContactsCount) && $unreadContactsCount > 0 ? '-fill text-warning' : ''); ?> me-2"></i>
            Messages
        </span>
        <?php if(!empty($unreadContactsCount) && $unreadContactsCount > 0): ?>
            <span class="badge bg-danger rounded-pill px-2 py-1" style="font-size: 0.75rem; font-weight: 600;">
                <?php echo e($unreadContactsCount); ?>

            </span>
        <?php endif; ?>
    </a>

    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Web_Settings')): ?>
        <?php
            $webSettingsRoutes = [
                'admin.settings.*',
                'admin.contact-social.*',
                'admin.homepage-carousel-images.*',
                'admin.counters.*',
                'admin.testimonials.*',
                'admin.faqs.*',
                'admin.about.*',
                'admin.team-members.*',
                'admin.partners.*',
                'admin.blogs.*',
                'admin.galleries.*',
                'admin.system-tools.*',
            ];
            $isWebSettingsActive = request()->routeIs($webSettingsRoutes);
        ?>
        <a class="d-flex justify-content-between align-items-center <?php echo e($isWebSettingsActive ? 'parent-active' : 'collapsed'); ?>"
            data-bs-toggle="collapse" href="#webSettingsMenu"
            role="button" aria-expanded="<?php echo e($isWebSettingsActive ? 'true' : 'false'); ?>" aria-controls="webSettingsMenu">
            <span><i class="bi bi-gear me-2"></i>Web Settings</span>
            <i class="bi bi-chevron-down"></i>
        </a>
        <div class="collapse ps-3 <?php echo e($isWebSettingsActive ? 'show' : ''); ?>" id="webSettingsMenu">
            <a href="<?php echo e(route('admin.settings.edit')); ?>"
                class="<?php echo e(request()->routeIs('admin.settings.*') ? 'active' : ''); ?>">General Settings</a>
            <a href="<?php echo e(route('admin.about.edit')); ?>"
                class="<?php echo e(request()->routeIs('admin.about.*') ? 'active' : ''); ?>">About Page</a>
            <a href="<?php echo e(route('admin.contact-social.edit')); ?>"
                class="<?php echo e(request()->routeIs('admin.contact-social.*') ? 'active' : ''); ?>">Contact &amp; Social Links</a>
            <a href="<?php echo e(route('admin.homepage-carousel-images.index')); ?>"
                class="<?php echo e(request()->routeIs('admin.homepage-carousel-images.*') ? 'active' : ''); ?>">Homepage Carousel Images</a>
            <a href="<?php echo e(route('admin.counters.index')); ?>"
                class="<?php echo e(request()->routeIs('admin.counters.*') ? 'active' : ''); ?>">Counters</a>
            <a href="<?php echo e(route('admin.testimonials.index')); ?>"
                class="<?php echo e(request()->routeIs('admin.testimonials.*') ? 'active' : ''); ?>">Testimonials</a>
            <a href="<?php echo e(route('admin.faqs.index')); ?>"
                class="<?php echo e(request()->routeIs('admin.faqs.*') ? 'active' : ''); ?>">FAQs</a>
            
            
            <a href="<?php echo e(route('admin.blogs.index')); ?>"
                class="<?php echo e(request()->routeIs('admin.blogs.*') ? 'active' : ''); ?>">Blogs</a>
            
            <a href="<?php echo e(route('admin.system-tools.index')); ?>"
                class="<?php echo e(request()->routeIs('admin.system-tools.*') ? 'active' : ''); ?>">
                <i class="bi bi-hdd-network me-1"></i> System &amp; Cache
            </a>
        </div>
    <?php endif; ?>

    
    

    
    

    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage services')): ?>
        <a href="<?php echo e(route('admin.services.index')); ?>"
            class="<?php echo e(request()->routeIs('admin.services.*') ? 'active' : ''); ?>">
            <i class="bi bi-tools me-2"></i> Services
        </a>
    <?php endif; ?>

    <div class="mt-auto pt-3 border-top border-secondary border-opacity-25">
        
        <a href="<?php echo e(Route::has('home') ? route('home') : url('/')); ?>" target="_blank"
            class="btn btn-outline-info w-100 text-start px-3 py-2 mb-2">
            <i class="bi bi-box-arrow-up-right me-2"></i> Visit Website
        </a>

        
        <form action="<?php echo e(route('admin.logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger w-100 text-start px-3 py-2">
                <i class="bi bi-box-arrow-right me-2"></i> Log Out
            </button>
        </form>
    </div>
</div>
<?php /**PATH C:\laragon\www\Computer_shop\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>