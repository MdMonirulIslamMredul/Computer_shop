<?php $__env->startSection('title', 'কাজের অর্ডার ও ডাটা এন্ট্রি তালিকা'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold mb-1 text-dark">অনলাইন আবেদন ও কাজের অর্ডার সমূহ</h3>
            <p class="text-muted mb-0">গ্রাহকদের প্রেরিত অনলাইন আবেদনের অগ্রগতি ও পেমেন্ট নিয়ন্ত্রণ করুন</p>
        </div>
        <div class="d-flex gap-2">
            <a href="<?php echo e(route('orders.create')); ?>" target="_blank" class="btn btn-outline-success">
                <i class="bi bi-plus-circle me-1"></i> নতুন অর্ডার ফরম
            </a>
            <a href="<?php echo e(route('orders.track')); ?>" target="_blank" class="btn btn-outline-primary">
                <i class="bi bi-search me-1"></i> পাবলিক ট্র্যাকিং
            </a>
        </div>
    </div>

    
    <div class="row g-3 mb-4">
        <div class="col-sm-6 col-xl-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white">
                <span class="text-muted small fw-semibold d-block mb-1">মোট অর্ডার</span>
                <h3 class="fw-bold text-dark mb-0"><?php echo e($stats['total']); ?></h3>
            </div>
        </div>
        <div class="col-sm-6 col-xl-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-warning">
                <span class="text-muted small fw-semibold d-block mb-1">অপেক্ষমাণ (Pending)</span>
                <h3 class="fw-bold text-warning mb-0"><?php echo e($stats['pending']); ?></h3>
            </div>
        </div>
        <div class="col-sm-6 col-xl-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-primary">
                <span class="text-muted small fw-semibold d-block mb-1">প্রক্রিয়াধীন (Processing)</span>
                <h3 class="fw-bold text-primary mb-0"><?php echo e($stats['processing']); ?></h3>
            </div>
        </div>
        <div class="col-sm-6 col-xl-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-success">
                <span class="text-muted small fw-semibold d-block mb-1">সম্পন্ন (Completed)</span>
                <h3 class="fw-bold text-success mb-0"><?php echo e($stats['completed']); ?></h3>
            </div>
        </div>
        <div class="col-sm-6 col-xl-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-info">
                <span class="text-muted small fw-semibold d-block mb-1">আজকের নতুন</span>
                <h3 class="fw-bold text-info mb-0"><?php echo e($stats['today']); ?></h3>
            </div>
        </div>
        <div class="col-sm-6 col-xl-2">
            <div class="card border-0 shadow-sm rounded-4 p-3 bg-white border-start border-4 border-danger">
                <span class="text-muted small fw-semibold d-block mb-1">যাচাইহীন পেমেন্ট</span>
                <h3 class="fw-bold text-danger mb-0"><?php echo e($stats['unverified_payments']); ?></h3>
            </div>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm rounded-4 mb-4">
        <div class="card-body p-3">
            <div class="row g-2 align-items-center justify-content-between">
                <div class="col-lg-8">
                    <ul class="nav nav-pills gap-1 flex-wrap">
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($status === 'all' ? 'active bg-dark' : 'text-secondary'); ?> py-1 px-3 rounded-pill"
                                href="<?php echo e(route('admin.orders.index', ['status' => 'all', 'search' => $search])); ?>">
                                সকল অর্ডার
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($status === 'pending' ? 'active bg-warning text-dark' : 'text-secondary'); ?> py-1 px-3 rounded-pill"
                                href="<?php echo e(route('admin.orders.index', ['status' => 'pending', 'search' => $search])); ?>">
                                অপেক্ষমাণ (<?php echo e($stats['pending']); ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($status === 'processing' ? 'active bg-primary' : 'text-secondary'); ?> py-1 px-3 rounded-pill"
                                href="<?php echo e(route('admin.orders.index', ['status' => 'processing', 'search' => $search])); ?>">
                                প্রক্রিয়াধীন (<?php echo e($stats['processing']); ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($status === 'completed' ? 'active bg-success' : 'text-secondary'); ?> py-1 px-3 rounded-pill"
                                href="<?php echo e(route('admin.orders.index', ['status' => 'completed', 'search' => $search])); ?>">
                                সম্পন্ন (<?php echo e($stats['completed']); ?>)
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo e($status === 'delivered' ? 'active bg-info text-dark' : 'text-secondary'); ?> py-1 px-3 rounded-pill"
                                href="<?php echo e(route('admin.orders.index', ['status' => 'delivered', 'search' => $search])); ?>">
                                ডেলিভারি
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <form action="<?php echo e(route('admin.orders.index')); ?>" method="GET">
                        <?php if($status !== 'all'): ?>
                            <input type="hidden" name="status" value="<?php echo e($status); ?>">
                        <?php endif; ?>
                        <div class="input-group">
                            <input type="text" name="search" class="form-control form-control-sm"
                                placeholder="ট্র্যাকিং আইডি, মোবাইল, TrxID..." value="<?php echo e($search); ?>">
                            <button type="submit" class="btn btn-sm btn-dark">
                                <i class="bi bi-search"></i>
                            </button>
                            <?php if($search): ?>
                                <a href="<?php echo e(route('admin.orders.index', ['status' => $status])); ?>" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-x"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">ট্র্যাকিং আইডি</th>
                        <th>গ্রাহকের তথ্য</th>
                        <th>সেবার নাম</th>
                        <th>ফি ও পেমেন্ট</th>
                        <th>অগ্রগতি স্ট্যাটাস</th>
                        <th>ডকুমেন্ট</th>
                        <th>তারিখ</th>
                        <th class="text-end pe-4">অ্যাকশন</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-4">
                                <strong class="font-monospace text-primary fs-6"><?php echo e($ord->tracking_id); ?></strong>
                            </td>
                            <td>
                                <strong class="text-dark d-block"><?php echo e($ord->customer_name); ?></strong>
                                <span class="text-muted small"><i class="bi bi-telephone me-1"></i><?php echo e($ord->customer_phone); ?></span>
                            </td>
                            <td>
                                <span class="fw-semibold text-dark"><?php echo e($ord->service_title); ?></span>
                            </td>
                            <td>
                                <div class="fw-bold text-dark">৳<?php echo e(number_format($ord->total_fee, 2)); ?></div>
                                <div class="small">
                                    <span class="badge <?php echo e($ord->payment_status_badge); ?>"><?php echo e($ord->payment_status_label); ?></span>
                                    <span class="text-muted ms-1 font-monospace"><?php echo e($ord->payment_method); ?></span>
                                </div>
                                <?php if($ord->transaction_id): ?>
                                    <div class="small text-muted font-monospace">TrxID: <?php echo e($ord->transaction_id); ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo e($ord->status_badge); ?> px-2 py-1"><?php echo e($ord->status_label); ?></span>
                                <?php if($ord->completed_file_path): ?>
                                    <div class="small text-success mt-1"><i class="bi bi-file-earmark-check-fill"></i> ফাইল আপলোড করা আছে</div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($ord->attachments->count() > 0): ?>
                                    <span class="badge bg-light text-secondary border">
                                        <i class="bi bi-paperclip me-1"></i> <?php echo e($ord->attachments->count()); ?>টি ফাইল
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted small">নেই</span>
                                <?php endif; ?>
                            </td>
                            <td class="small text-muted">
                                <?php echo e($ord->created_at->format('d M, Y')); ?><br>
                                <span class="text-muted" style="font-size: 0.75rem;"><?php echo e($ord->created_at->format('h:i A')); ?></span>
                            </td>
                            <td class="text-end pe-4">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('admin.orders.show', $ord->id)); ?>" class="btn btn-primary" title="বিস্তারিত দেখুন">
                                        <i class="bi bi-eye"></i> দেখুন
                                    </a>
                                    <a href="<?php echo e(route('admin.orders.print', $ord->id)); ?>" target="_blank" class="btn btn-outline-secondary" title="রসিদ প্রিন্ট">
                                        <i class="bi bi-printer"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.orders.destroy', $ord->id)); ?>" method="POST" class="d-inline"
                                        onsubmit="return confirm('আপনি কি নিশ্চিত এই অর্ডারটি মুছে ফেলতে চান?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger" title="ডিলিট">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-5">
                                <i class="bi bi-inbox text-muted fs-1 mb-2 d-block"></i>
                                <span class="text-muted">কোনো অর্ডার পাওয়া যায়নি।</span>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if($orders->hasPages()): ?>
            <div class="card-footer bg-white border-top py-3 d-flex justify-content-center">
                <?php echo e($orders->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Computer_shop\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>