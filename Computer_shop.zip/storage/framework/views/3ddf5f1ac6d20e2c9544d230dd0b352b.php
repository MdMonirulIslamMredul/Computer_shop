<?php $__env->startSection('title', 'Blogs'); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between mb-3">
        <h4>Blogs</h4><a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-primary">Add Blog</a>
    </div>
    <div class="card p-3">
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Published</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($blog->title); ?></td>
                        <td><?php echo e($blog->is_published ? 'Yes' : 'No'); ?></td>
                        <td class="text-end"><a href="<?php echo e(route('admin.blogs.edit', $blog)); ?>"
                                class="btn btn-sm btn-outline-primary">Edit</a>
                            <form method="POST" action="<?php echo e(route('admin.blogs.destroy', $blog)); ?>" class="d-inline"><?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?><button onclick="return confirm('Delete item?')"
                                    class="btn btn-sm btn-outline-danger">Delete</button></form>
                        </td>
                </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr>
                        <td colspan="3">No blogs found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table><?php echo e($blogs->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Computer_shop\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>