<div class="topbar bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
    <div class="d-flex align-items-center gap-2">
        <button class="btn btn-sm btn-outline-secondary d-lg-none" type="button" data-bs-toggle="offcanvas" data-bs-target="#adminSidebar" aria-controls="adminSidebar" aria-label="Toggle navigation">
            <i class="bi bi-list fs-5 lh-1"></i>
        </button>
        <span class="fw-bold d-none d-sm-inline">Welcome, <?php echo e(auth()->user()->name); ?></span>
        <span class="fw-bold d-inline d-sm-none text-truncate" style="max-width: 130px;" title="<?php echo e(auth()->user()->name); ?>">
            <?php echo e(auth()->user()->name); ?>

        </span>
    </div>
    <div class="d-flex align-items-center gap-2 gap-sm-3">
        <a href="<?php echo e(Route::has('home') ? route('home') : url('/')); ?>" target="_blank" class="btn btn-sm btn-outline-secondary" title="View Frontend Website">
            <i class="bi bi-globe"></i>
        </a>
        <a href="<?php echo e(route('admin.contacts.index')); ?>" class="btn btn-sm btn-outline-secondary position-relative" title="Contact Messages">
            <i class="bi bi-envelope"></i>
            <?php if(!empty($unreadContactsCount) && $unreadContactsCount > 0): ?>
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.65rem;">
                    <?php echo e($unreadContactsCount); ?>

                    <span class="visually-hidden">unread messages</span>
                </span>
            <?php endif; ?>
        </a>
        <div class="dropdown">
            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" id="adminUserMenu"
                data-bs-toggle="dropdown" aria-expanded="false">
                <i class="bi bi-person-circle"></i> <span class="d-none d-sm-inline"><?php echo e(auth()->user()->name); ?></span>
            </button>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="adminUserMenu">
                <li><a class="dropdown-item" href="<?php echo e(Route::has('home') ? route('home') : url('/')); ?>" target="_blank"><i class="bi bi-box-arrow-up-right me-2"></i>Visit Website</a></li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.profile')); ?>">Profile</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.password.edit')); ?>">Change Password</a></li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li>
                    <form action="<?php echo e(route('admin.logout')); ?>" method="POST" class="m-0">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dropdown-item">Logout</button>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Computer_shop\resources\views/admin/partials/topbar.blade.php ENDPATH**/ ?>