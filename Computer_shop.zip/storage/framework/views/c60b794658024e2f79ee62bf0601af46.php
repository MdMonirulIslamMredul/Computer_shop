<?php $__env->startSection('title', 'Gallery'); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between mb-3">
        <h4>Gallery</h4><a href="<?php echo e(route('admin.galleries.create')); ?>" class="btn btn-primary">Add Gallery Item</a>
    </div>
    <div class="card p-3">
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($gallery->title); ?></td>
                        <td><?php echo e(ucfirst($gallery->type)); ?></td>
                        <td><?php echo e($gallery->status ? 'Active' : 'Inactive'); ?></td>
                        <td class="text-end"><a href="<?php echo e(route('admin.galleries.edit', $gallery)); ?>"
                                class="btn btn-sm btn-outline-primary">Edit</a>
                            <form method="POST" action="<?php echo e(route('admin.galleries.destroy', $gallery)); ?>" class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button onclick="return confirm('Delete item?')"
                                    class="btn btn-sm btn-outline-danger">Delete</button></form>
                        </td>
                </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr>
                        <td colspan="4">No gallery items found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table><?php echo e($galleries->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Computer_shop\resources\views/admin/galleries/index.blade.php ENDPATH**/ ?>